/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InventoryManagementSystem;
import java.util.Scanner;
/**
 *
 * @author jyoti1
 */
public class InventoryManagementSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n🛒 Inventory Menu");
            System.out.println("1. Add Product");
            System.out.println("2. Update Product Quantity");
            System.out.println("3. Remove Product");
            System.out.println("4. View All Products");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1 : AddProduct.add(); break;
                case 2 : UpdateProduct.update(); break;
                case 3 : RemoveProduct.remove(); break;
                case 4 : ViewProducts.view(); break;
                case 5 : System.out.println("? Exiting..."); break;
                default : System.out.println(" Invalid Option");
            }
        } while (choice != 5);
        sc.close();
    }
}
