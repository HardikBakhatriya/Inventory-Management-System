/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InventoryManagementSystem;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author jyoti
 */
public class RemoveProduct {
    public static void remove() {
        try {
            Scanner sc = new Scanner(System.in);

            System.out.print("Enter Product ID to delete: ");
            int id = sc.nextInt();

            String sql = "DELETE FROM products WHERE id = ?";
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ps.setInt(1, id);

            int rows = ps.executeUpdate();
            if (rows > 0)
                System.out.println("🗑️ Product Deleted!");
            else
                System.out.println("❌ Product Not Found!");

        } catch (SQLException e) {
            System.out.println("❌ Error Deleting Product: " + e.getMessage());
        }
    }
}
