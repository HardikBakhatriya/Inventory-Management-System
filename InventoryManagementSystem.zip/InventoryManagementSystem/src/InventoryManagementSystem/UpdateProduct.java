/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InventoryManagementSystem;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
/**
 *
 * @author jyoti
 */
public class UpdateProduct {
    public static void update() {
        try {
            Scanner sc = new Scanner(System.in);

            System.out.print("Enter Product ID to update: ");
            int id = sc.nextInt();

            System.out.print("Enter New Quantity: ");
            int qty = sc.nextInt();

            String sql = "UPDATE products SET quantity = ? WHERE id = ?";
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ps.setInt(1, qty);
            ps.setInt(2, id);

            int rows = ps.executeUpdate();
            if (rows > 0)
                System.out.println("✅ Quantity Updated!");
            else
                System.out.println("❌ Product Not Found!");

        } catch (SQLException e) {
            System.out.println("❌ Error Updating Product: " + e.getMessage());
        }
    }
}
