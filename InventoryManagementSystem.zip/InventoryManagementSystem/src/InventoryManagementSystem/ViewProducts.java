/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InventoryManagementSystem;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/**
 *
 * @author jyoti
 */
class ViewProducts {
    public static void view() {
        try {
            Statement st = DBConnection.getStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM products");

            System.out.println("\n📦 Product List:");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id")
                        + ", Name: " + rs.getString("name")
                        + ", Quantity: " + rs.getInt("quantity"));
            }
        } catch (SQLException e) {
            System.out.println("❌ Error Viewing Products: " + e.getMessage());
        }
    }
}
